﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TimeshareManagement.Models.Models.DTO
{
    public class RoomAmenitiesDTO
    {
        public int roomAmenitiesId { get; set; }
        public string roomAmenitiesName { get; set; }
        /*public RoomDetailDTO? RoomDetail { get; set; }*/

    }
}
