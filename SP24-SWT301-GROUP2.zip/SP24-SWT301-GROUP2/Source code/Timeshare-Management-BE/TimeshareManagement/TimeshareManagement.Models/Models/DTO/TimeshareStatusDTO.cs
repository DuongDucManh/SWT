﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TimeshareManagement.Models.Models.DTO
{
    public class TimeshareStatusDTO
    {
        public int timeshareStatusId { get; set; }
        public string? timeshareStatusName { get; set; }
    }
}
