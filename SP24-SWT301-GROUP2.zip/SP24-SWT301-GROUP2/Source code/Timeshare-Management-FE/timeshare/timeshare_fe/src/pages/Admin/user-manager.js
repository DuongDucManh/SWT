import TableUserManagement from "../../Components/UserManagement/Table";

function UserManagerPage() {
  return (
    <>
      <TableUserManagement />
    </>
  );
}

export default UserManagerPage;
