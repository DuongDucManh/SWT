export const apiGetAllUser = "User/GetAllUser";
export const apiGetUserById = "User/GetUserById";
export const apiUpdateUser = "User/UpdateUser";
export const apiDeleteUser = "User/DeleteUser";
