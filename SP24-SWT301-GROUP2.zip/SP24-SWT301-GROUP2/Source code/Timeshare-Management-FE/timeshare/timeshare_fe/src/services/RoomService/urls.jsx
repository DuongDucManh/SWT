export const apiGetAllRoom = "room/GetAllRoom";
export const apiGetRoomById = "room/GetRoomById";
export const apiCreateRoom = "room/CreateRoom";
export const apiUpdateRoom = "room/UpdateRoom";
export const apiDeleteRoom = "room/DeleteRoom";
