export const apiGetAllTimeshare = "timeshare/GetAllTimeshare";
export const apiGetTimeshareById = "timeshare/GetTimeshareById";
export const apiCreateTimeshare = "timeshare/CreateTimeshare";
export const apiUpdateTimeshare = "timeshare/UpdateTimeshare";
export const apiDeleteTimeshare = "timeshare/DeleteTimeshare";
